/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (C) 2015 Freescale Semiconductor, Inc.
 */

#ifndef __ASM_ARCH_MX7_GPIO_H
#define __ASM_ARCH_MX7_GPIO_H

#include <asm/mach-imx/gpio.h>

#endif /* __ASM_ARCH_MX7_GPIO_H */
