/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (C) 2019
 * Author(s): Giulio Benetti <giulio.benetti@benettiengineering.com>
 */

#ifndef _ASM_ARCH_IMXRT_H
#define _ASM_ARCH_IMXRT_H

#endif /* _ASM_ARCH_IMXRT_H */
