# Version number and release date.
# VERSION_NUMBER should be
#  = MAJOR.MINOR for release,
#  = MAJOR.MINOR+ for development after MAJOR.MINOR, and
#  = MAJOR.MINOR++ for pretest (becomes (MINOR+1) on release)
# RELEASE_DATE should be the date when VERSION_NUMBER was modified.
VERSION_NUMBER=2.49.60+
RELEASE_DATE=2017-06-25         # in "date +%F" format
