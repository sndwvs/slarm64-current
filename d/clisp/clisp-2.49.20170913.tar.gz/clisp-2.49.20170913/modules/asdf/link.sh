${MAKE-make} clisp-module \
  CLISP_LINKKIT="$absolute_linkkitdir" CLISP="${CLISP}"
NEW_MODULES='asdf'
NEW_FILES=""
NEW_LIBS=""
TO_LOAD='asdf'
TO_PRELOAD=""
